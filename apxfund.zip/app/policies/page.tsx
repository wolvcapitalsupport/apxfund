import PublicHeader from '@/components/layout/PublicHeader'
import PublicFooter from '@/components/layout/PublicFooter'
import Link from 'next/link'

const SECTIONS = [
  {
    title: '1. Acceptance of Terms',
    content: `By registering an account and using the APXFund platform, you confirm that you have read, understood, and agreed to these Terms and Conditions in full. If you do not agree to these terms, you must not use our platform. APXFund reserves the right to update these policies at any time, and continued use of the platform constitutes acceptance of any revisions.`,
  },
  {
    title: '2. Eligibility',
    content: `You must be at least 18 years of age to create an account and invest on this platform. By registering, you represent and warrant that you are legally permitted to participate in investment activities in your jurisdiction. Users from jurisdictions where such activities are prohibited are not permitted to use this platform.`,
  },
  {
    title: '3. Investment Plans & Returns',
    content: `APXFund offers four investment plans: Starter Portfolio (3.5% ROI / 7 days), Growth Fund (12% ROI / 14 days), Apex Fund (22% ROI / 30 days), and Sovereign Tier (38% ROI / 30 days). Returns are credited automatically upon maturity. All plans include capital insurance covering the principal invested. Past performance does not guarantee future results. Investment activities carry inherent risk. Exact rates and minimum/maximum amounts for each plan are displayed on the Investment Plans page at the time of investment and take precedence over this summary if they differ.`,
  },
  {
    title: '3a. Starter Portfolio Cycle Limit & Migration',
    content: `Starter Portfolio is limited to 2 investment cycles per account, for the lifetime of that account. Once both cycles are complete, no further Starter Portfolio investments can be opened on that account. Profit from each Starter Portfolio cycle is credited to your withdrawable balance immediately at that cycle's completion — this is never delayed or affected by the points below. Capital, however, is not released to your balance when the second cycle completes. Instead, it remains locked on the platform until you migrate it into a higher-tier plan (Growth Fund, Apex Fund, or Sovereign Tier), at which point your locked capital plus any required top-up becomes the principal of your new investment. There is no deadline to migrate — locked capital is held safely on your account indefinitely until you choose to act. Your dashboard will display the exact top-up required for each eligible plan once your capital is locked.`,
  },
  {
    title: '3b. Auto-Rollover (Growth Fund, Apex Fund, Sovereign Tier)',
    content: `Unlike Starter Portfolio, investments in Growth Fund, Apex Fund, and Sovereign Tier automatically roll over into a new cycle of the same plan when they mature, by default: profit is credited to your balance and your capital immediately begins a new cycle without any action from you. You may disable this behavior for an individual investment at any time from its investment card on the dashboard ("Stop Renewing"). When disabled, both capital and profit are credited to your balance at that investment's next maturity, and no further cycle is started automatically.`,
  },
  {
    title: '4. Deposits',
    content: `Deposits are accepted via Bitcoin (BTC), Ethereum (ETH), and Tether (USDT/TRC20). All deposits must include a valid transaction hash for verification. Deposits are subject to administrative review and are typically credited within 30 minutes of blockchain confirmation. APXFund reserves the right to reject deposits that cannot be verified or that originate from sanctioned addresses.`,
  },
  {
    title: '5. Withdrawals',
    content: `Withdrawals are only available to users who have at least one fully matured investment plan. Funds deposited must be placed into an active investment plan and allowed to complete its full duration before a withdrawal request can be submitted. The minimum withdrawal amount is $10 USD. Withdrawal requests are processed within 24 hours of submission. Users are responsible for providing accurate wallet addresses — APXFund accepts no liability for funds sent to incorrect addresses. Withdrawals may be subject to compliance checks and may be delayed where suspicious activity is detected.`,
  },
  {
    title: '6. KYC & Identity Verification',
    content: `To comply with global AML and KYC regulations, all users are required to complete identity verification before accessing full platform features. This includes submission of a government-issued photo ID and a selfie. Documents are reviewed by our compliance team within 24-48 hours. APXFund reserves the right to suspend accounts where KYC requirements are not met.`,
  },
  {
    title: '7. Referral Program',
    content: `The referral program rewards users for introducing new investors. Referral bonuses vary by the referred investor's plan and are shown on the Investment Plans page. Bonuses are credited automatically upon the referred user's first completed investment cycle. Referral fraud, including self-referral or fabricated accounts, will result in immediate account termination and forfeiture of all bonuses.`,
  },
  {
    title: '8. Capital Insurance Policy',
    content: `APXFund maintains an insurance policy covering investor principal against trading losses. In the event trading performance causes a deficit, insured principal is protected up to the value of each individual investment. APXFund also maintains an Employee Negligence cover of up to $1,000,000. Insurance does not cover losses resulting from user error (e.g. incorrect withdrawal addresses) or violations of these terms.`,
  },
  {
    title: '9. Account Security',
    content: `Users are solely responsible for maintaining the security of their login credentials. APXFund will never ask for your password via email or chat. You must immediately notify us at support@apxfund.xyz if you suspect unauthorised access to your account. APXFund cannot be held liable for losses resulting from compromised credentials caused by user negligence.`,
  },
  {
    title: '10. Prohibited Activities',
    content: `Users must not engage in money laundering, fraud, market manipulation, or any other unlawful activity through this platform. Multiple accounts per person are prohibited. Automated scripting, bots, or programmatic access to the platform without written consent is forbidden. Violation of any of these prohibitions will result in immediate account suspension and reporting to relevant authorities.`,
  },
  {
    title: '11. Privacy Policy',
    content: `APXFund collects personal data solely for the purpose of operating the platform, fulfilling regulatory requirements, and improving our services. We do not sell personal data to third parties. Data is stored securely using industry-standard encryption. You may request deletion of your account and associated data by contacting support@apxfund.xyz. Regulatory records may be retained for up to 7 years as required by law.`,
  },
  {
    title: '12. Limitation of Liability',
    content: `APXFund shall not be liable for any indirect, incidental, or consequential damages arising from use of the platform, including but not limited to loss of profit, loss of data, or business interruption. Our total liability to any individual user shall not exceed the amount invested by that user in the 90 days preceding the event giving rise to the claim.`,
  },
  {
    title: '13. Governing Law',
    content: `These Terms shall be governed by and construed in accordance with the laws of the State of Pennsylvania, United States of America. Any disputes arising under or in connection with these Terms shall be subject to the exclusive jurisdiction of the courts of Pennsylvania.`,
  },
  {
    title: '14. Contact',
    content: `For questions, complaints, or legal notices regarding these policies, please contact: APXFund Compliance Team · 3536 Badger Pond Lane, Pittsburgh, PA 15212, United States · support@apxfund.xyz · +44 7876 263 213`,
  },
]

export default function PoliciesPage() {
  return (
    <div className="min-h-screen bg-[#0a0a14] text-white">
      <PublicHeader />

      {/* Header */}
      <section className="py-20 max-w-4xl mx-auto px-6 text-center">
        <div className="text-[#c9a84c] text-sm font-semibold uppercase tracking-widest mb-4">Legal</div>
        <h1 className="text-5xl font-black mb-4">Company <span className="gold-text">Policies</span></h1>
        <p className="text-gray-400">
          Last updated: March 2025 · Please read these terms carefully before using APXFund.
        </p>
      </section>

      {/* Policies content */}
      <section className="pb-24 max-w-4xl mx-auto px-6">
        <div className="space-y-6">
          {SECTIONS.map(({ title, content }) => (
            <div key={title} className="card-dark p-6 hover:border-[#c9a84c]/20 transition-all">
              <h2 className="font-bold text-lg mb-3 text-white">{title}</h2>
              <p className="text-gray-400 text-sm leading-relaxed">{content}</p>
            </div>
          ))}
        </div>

        {/* Agreement CTA */}
        <div className="mt-12 card-dark p-8 text-center border-[#c9a84c]/20">
          <h3 className="text-2xl font-black mb-3">Ready to <span className="gold-text">Get Started?</span></h3>
          <p className="text-gray-400 text-sm mb-6">
            By creating an account, you confirm that you have read and accept these policies.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/auth/register" className="btn-gold px-6 py-3 rounded-xl text-sm">
              Create Account
            </Link>
            <a href="mailto:support@apxfund.xyz"
              className="px-6 py-3 rounded-xl border border-[#1e1e35] text-gray-300 hover:border-[#c9a84c] text-sm transition-all">
              Contact Support
            </a>
          </div>
        </div>
      </section>

      <PublicFooter />
    </div>
  )
}
